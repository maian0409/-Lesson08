using Lesson08_BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace Lesson08_BookStore.Data;

public class BookStoreContext : DbContext
{
    public BookStoreContext(DbContextOptions<BookStoreContext> options) : base(options) { }

    public DbSet<Book> Books => Set<Book>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Publisher> Publishers => Set<Publisher>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Book>(entity =>
        {
            entity.ToTable("Book");
            entity.HasKey(e => e.BookId);
            entity.Property(e => e.BookId).HasMaxLength(10).IsUnicode(false);
            entity.Property(e => e.Title).HasMaxLength(200);
            entity.Property(e => e.Author).HasMaxLength(100);
            entity.Property(e => e.Description).HasColumnType("ntext");
            entity.Property(e => e.Picture).HasMaxLength(100);
            entity.HasOne(e => e.Publisher).WithMany(e => e.Books)
                .HasForeignKey(e => e.PublisherId);
            entity.HasOne(e => e.Category).WithMany(e => e.Books)
                .HasForeignKey(e => e.CategoryId);
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.ToTable("Category");
            entity.HasKey(e => e.CategoryId);
            entity.Property(e => e.CategoryName).HasMaxLength(100);
        });

        modelBuilder.Entity<Publisher>(entity =>
        {
            entity.ToTable("Publisher");
            entity.HasKey(e => e.PublisherId);
            entity.Property(e => e.PublisherName).HasMaxLength(200);
            entity.Property(e => e.Phone).HasMaxLength(30).IsUnicode(false);
            entity.Property(e => e.Address).HasMaxLength(200);
        });
    }
}
