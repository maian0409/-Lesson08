# Lesson 08 - BookStore (ASP.NET Core MVC + EF Core)

Project mẫu quản lý sách, sử dụng SQL Server và Entity Framework Core. Cấu trúc được tổ chức theo cách Database First: database là nguồn dữ liệu chính, các lớp `Book`, `Category`, `Publisher` và `BookStoreContext` ánh xạ tới các bảng hiện có.

## 1. Chuẩn bị database

1. Mở SQL Server Management Studio (SSMS).
2. Chạy file `Database/BookStoreDB.sql`.
3. Nếu SQL Server của bạn không dùng instance mặc định, hãy sửa chuỗi kết nối trong `appsettings.json`.

Chuỗi kết nối mặc định:

`Server=.;Database=BookStoreDB;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true`

## 2. Mở và chạy

1. Giải nén ZIP.
2. Mở `Lesson08_BookStore.csproj` bằng Visual Studio 2026.
3. Đợi NuGet restore hoàn tất.
4. Nhấn F5 hoặc Ctrl+F5.
5. Trình duyệt mở trang danh sách sách.

Yêu cầu: .NET 10 SDK và SQL Server/Local SQL Server đã cài đặt. Nếu Visual Studio chưa có .NET 10 SDK, cài workload **ASP.NET and web development** và .NET 10 SDK.

## 3. Chức năng

- Xem danh sách sách
- Tìm kiếm theo mã sách, tên sách hoặc tác giả
- Xem chi tiết
- Thêm sách
- Sửa sách
- Xóa sách có bước xác nhận
- Hiển thị thể loại và nhà xuất bản theo quan hệ khóa ngoại

## 4. Nếu cần sinh model trực tiếp từ database bằng Scaffold (Database First)

Sau khi tạo project MVC và cài package EF Core cùng phiên bản với target framework, mở **Tools > NuGet Package Manager > Package Manager Console** và chạy:

```powershell
Scaffold-DbContext "Server=.;Database=BookStoreDB;Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models/Scaffolded -Context BookStoreScaffoldContext -DataAnnotations -Force
```

Lệnh trên sinh lại các entity từ database. Project ZIP đã có sẵn các entity và DbContext được ánh xạ để có thể chạy ngay sau khi cấu hình đúng chuỗi kết nối.

## Lưu ý

- Tài khoản SQL Server của bạn có thể cần thay `Server=.` bằng tên server đang dùng trong SSMS, ví dụ `.\SQLEXPRESS` hoặc `(localdb)\\MSSQLLocalDB`.
- Script SQL ban đầu có thể cần điều chỉnh dữ liệu mẫu `OrderBook.AccountId` nếu giá trị GUID không trùng với `NEWID()` tạo ra cho tài khoản. Phần CRUD sách của project không phụ thuộc vào bảng đơn hàng.
