using Lesson08_BookStore.Data;
using Lesson08_BookStore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Lesson08_BookStore.Controllers;

public class BooksController : Controller
{
    private readonly BookStoreContext _context;

    public BooksController(BookStoreContext context) => _context = context;

    public async Task<IActionResult> Index(string? searchString)
    {
        var books = _context.Books
            .Include(b => b.Category)
            .Include(b => b.Publisher)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(searchString))
        {
            books = books.Where(b => b.Title.Contains(searchString) ||
                                     (b.Author != null && b.Author.Contains(searchString)) ||
                                     b.BookId.Contains(searchString));
        }

        ViewData["SearchString"] = searchString;
        return View(await books.OrderBy(b => b.Title).ToListAsync());
    }

    public async Task<IActionResult> Details(string? id)
    {
        if (id == null) return NotFound();
        var book = await _context.Books
            .Include(b => b.Category).Include(b => b.Publisher)
            .FirstOrDefaultAsync(b => b.BookId == id);
        return book == null ? NotFound() : View(book);
    }

    public IActionResult Create()
    {
        LoadSelections();
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("BookId,Title,Author,Release,Price,Description,Picture,PublisherId,CategoryId")] Book book)
    {
        if (ModelState.IsValid)
        {
            if (await _context.Books.AnyAsync(b => b.BookId == book.BookId))
            {
                ModelState.AddModelError(nameof(book.BookId), "Mã sách đã tồn tại.");
            }
            else
            {
                _context.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
        }
        LoadSelections(book.CategoryId, book.PublisherId);
        return View(book);
    }

    public async Task<IActionResult> Edit(string? id)
    {
        if (id == null) return NotFound();
        var book = await _context.Books.FindAsync(id);
        if (book == null) return NotFound();
        LoadSelections(book.CategoryId, book.PublisherId);
        return View(book);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(string id, [Bind("BookId,Title,Author,Release,Price,Description,Picture,PublisherId,CategoryId")] Book book)
    {
        if (id != book.BookId) return NotFound();
        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!await _context.Books.AnyAsync(e => e.BookId == book.BookId)) return NotFound();
                throw;
            }
        }
        LoadSelections(book.CategoryId, book.PublisherId);
        return View(book);
    }

    public async Task<IActionResult> Delete(string? id)
    {
        if (id == null) return NotFound();
        var book = await _context.Books.Include(b => b.Category).Include(b => b.Publisher)
            .FirstOrDefaultAsync(b => b.BookId == id);
        return book == null ? NotFound() : View(book);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(string id)
    {
        var book = await _context.Books.FindAsync(id);
        if (book != null)
        {
            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

    private void LoadSelections(int? categoryId = null, int? publisherId = null)
    {
        ViewData["CategoryId"] = new SelectList(_context.Categories.OrderBy(c => c.CategoryName),
            "CategoryId", "CategoryName", categoryId);
        ViewData["PublisherId"] = new SelectList(_context.Publishers.OrderBy(p => p.PublisherName),
            "PublisherId", "PublisherName", publisherId);
    }
}
