using System.ComponentModel.DataAnnotations;

namespace Lesson08_BookStore.Models;

public class Publisher
{
    [Key]
    [Display(Name = "Mã nhà xuất bản")]
    public int PublisherId { get; set; }

    [StringLength(200)]
    [Display(Name = "Nhà xuất bản")]
    public string? PublisherName { get; set; }

    [StringLength(30)]
    [Display(Name = "Điện thoại")]
    public string? Phone { get; set; }

    [StringLength(200)]
    [Display(Name = "Địa chỉ")]
    public string? Address { get; set; }

    public ICollection<Book> Books { get; set; } = new List<Book>();
}
