using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lesson08_BookStore.Models;

public class Book
{
    [Key, StringLength(10)]
    [Display(Name = "Mã sách")]
    public string BookId { get; set; } = "";

    [Required, StringLength(200)]
    [Display(Name = "Tên sách")]
    public string Title { get; set; } = "";

    [StringLength(100)]
    [Display(Name = "Tác giả")]
    public string? Author { get; set; }

    [Display(Name = "Năm phát hành")]
    public int? Release { get; set; }

    [Column(TypeName = "float")]
    [Display(Name = "Giá")]
    [Range(0, 1000000000)]
    public double? Price { get; set; }

    [Column(TypeName = "ntext")]
    [Display(Name = "Mô tả")]
    public string? Description { get; set; }

    [StringLength(100)]
    [Display(Name = "Ảnh")]
    public string? Picture { get; set; }

    [Display(Name = "Nhà xuất bản")]
    public int? PublisherId { get; set; }

    [Display(Name = "Thể loại")]
    public int? CategoryId { get; set; }

    public Publisher? Publisher { get; set; }
    public Category? Category { get; set; }
}
