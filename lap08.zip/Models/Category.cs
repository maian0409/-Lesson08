using System.ComponentModel.DataAnnotations;

namespace Lesson08_BookStore.Models;

public class Category
{
    [Key]
    [Display(Name = "Mã thể loại")]
    public int CategoryId { get; set; }

    [StringLength(100)]
    [Display(Name = "Tên thể loại")]
    public string? CategoryName { get; set; }

    public ICollection<Book> Books { get; set; } = new List<Book>();
}
